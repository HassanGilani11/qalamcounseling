<?php exit; ?>
[2023-12-07 13:27:18] ERROR: Form 8 > Mailchimp API error: 401 Unauthorized. API Key Invalid. API key has been disabled

Request: 
GET https://us12.api.mailchimp.com/3.0/lists/88cc356196/members/30a3a969ab3ee0c47cd805959d54b49f


Response: 
401 Unauthorized
{"type":"https://mailchimp.com/developer/marketing/docs/errors/","title":"API Key Invalid","status":401,"detail":"API key has been disabled","instance":"46cb5f1f-9b00-2bcc-1328-f3509c945d14"}
[2023-12-07 13:27:24] ERROR: Form 8 > Mailchimp API error: 401 Unauthorized. API Key Invalid. API key has been disabled

Request: 
GET https://us12.api.mailchimp.com/3.0/lists/88cc356196/members/1e02867f2be32e3578af7fe544199da9


Response: 
401 Unauthorized
{"type":"https://mailchimp.com/developer/marketing/docs/errors/","title":"API Key Invalid","status":401,"detail":"API key has been disabled","instance":"5cbe05af-8e39-a835-d18b-c8156e95b0f2"}
[2023-12-07 13:27:27] ERROR: Form 8 > Mailchimp API error: 401 Unauthorized. API Key Invalid. API key has been disabled

Request: 
GET https://us12.api.mailchimp.com/3.0/lists/88cc356196/members/fab6a15d8d456660d42c29afa55a063b


Response: 
401 Unauthorized
{"type":"https://mailchimp.com/developer/marketing/docs/errors/","title":"API Key Invalid","status":401,"detail":"API key has been disabled","instance":"5b7bbe30-4bd7-8530-b04d-e16a2e6483c0"}
[2023-12-07 13:27:32] ERROR: Form 8 > Mailchimp API error: 401 Unauthorized. API Key Invalid. API key has been disabled

Request: 
GET https://us12.api.mailchimp.com/3.0/lists/88cc356196/members/30a3a969ab3ee0c47cd805959d54b49f


Response: 
401 Unauthorized
{"type":"https://mailchimp.com/developer/marketing/docs/errors/","title":"API Key Invalid","status":401,"detail":"API key has been disabled","instance":"d6bcda44-3234-8619-8316-eb998521aaea"}
[2023-12-07 13:27:35] ERROR: Form 8 > Mailchimp API error: 401 Unauthorized. API Key Invalid. API key has been disabled

Request: 
GET https://us12.api.mailchimp.com/3.0/lists/88cc356196/members/30a3a969ab3ee0c47cd805959d54b49f


Response: 
401 Unauthorized
{"type":"https://mailchimp.com/developer/marketing/docs/errors/","title":"API Key Invalid","status":401,"detail":"API key has been disabled","instance":"2d33b63d-ecce-a9a9-9a27-884f920af69b"}
[2023-12-07 13:27:39] ERROR: Form 8 > Mailchimp API error: 401 Unauthorized. API Key Invalid. API key has been disabled

Request: 
GET https://us12.api.mailchimp.com/3.0/lists/88cc356196/members/30a3a969ab3ee0c47cd805959d54b49f


Response: 
401 Unauthorized
{"type":"https://mailchimp.com/developer/marketing/docs/errors/","title":"API Key Invalid","status":401,"detail":"API key has been disabled","instance":"1b699038-75b7-90d6-2e8f-f389f11c2cf6"}
[2023-12-07 13:28:33] ERROR: Form 8 > Mailchimp API error: 401 Unauthorized. API Key Invalid. API key has been disabled

Request: 
GET https://us12.api.mailchimp.com/3.0/lists/88cc356196/members/52d5f7f4f8a2f4d69c116afc5c2d61f9


Response: 
401 Unauthorized
{"type":"https://mailchimp.com/developer/marketing/docs/errors/","title":"API Key Invalid","status":401,"detail":"API key has been disabled","instance":"e03b8aaf-bc1c-5682-d0b2-a2a88bb33459"}
[2023-12-07 13:28:38] ERROR: Form 8 > Mailchimp API error: 401 Unauthorized. API Key Invalid. API key has been disabled

Request: 
GET https://us12.api.mailchimp.com/3.0/lists/88cc356196/members/1e02867f2be32e3578af7fe544199da9


Response: 
401 Unauthorized
{"type":"https://mailchimp.com/developer/marketing/docs/errors/","title":"API Key Invalid","status":401,"detail":"API key has been disabled","instance":"eb3d4785-7b26-e8a9-b900-a6ea383141b1"}
[2023-12-07 13:28:42] ERROR: Form 8 > Mailchimp API error: 401 Unauthorized. API Key Invalid. API key has been disabled

Request: 
GET https://us12.api.mailchimp.com/3.0/lists/88cc356196/members/52d5f7f4f8a2f4d69c116afc5c2d61f9


Response: 
401 Unauthorized
{"type":"https://mailchimp.com/developer/marketing/docs/errors/","title":"API Key Invalid","status":401,"detail":"API key has been disabled","instance":"224c13bb-dee5-97cf-0476-72d8df2b0b72"}
[2023-12-07 13:28:46] ERROR: Form 8 > Mailchimp API error: 401 Unauthorized. API Key Invalid. API key has been disabled

Request: 
GET https://us12.api.mailchimp.com/3.0/lists/88cc356196/members/fab6a15d8d456660d42c29afa55a063b


Response: 
401 Unauthorized
{"type":"https://mailchimp.com/developer/marketing/docs/errors/","title":"API Key Invalid","status":401,"detail":"API key has been disabled","instance":"92ec515e-cdd1-59fb-5b40-e94eba5672a8"}
[2023-12-07 13:28:49] ERROR: Form 8 > Mailchimp API error: 401 Unauthorized. API Key Invalid. API key has been disabled

Request: 
GET https://us12.api.mailchimp.com/3.0/lists/88cc356196/members/fab6a15d8d456660d42c29afa55a063b


Response: 
401 Unauthorized
{"type":"https://mailchimp.com/developer/marketing/docs/errors/","title":"API Key Invalid","status":401,"detail":"API key has been disabled","instance":"d04944ff-1d3c-712e-6f79-295601b3a646"}
[2023-12-07 13:28:55] ERROR: Form 8 > Mailchimp API error: 401 Unauthorized. API Key Invalid. API key has been disabled

Request: 
GET https://us12.api.mailchimp.com/3.0/lists/88cc356196/members/fab6a15d8d456660d42c29afa55a063b


Response: 
401 Unauthorized
{"type":"https://mailchimp.com/developer/marketing/docs/errors/","title":"API Key Invalid","status":401,"detail":"API key has been disabled","instance":"7ffa4378-d3d6-85cd-73bf-5f64b03ebb7c"}
[2023-12-07 13:29:54] ERROR: Form 8 > Mailchimp API error: 401 Unauthorized. API Key Invalid. API key has been disabled

Request: 
GET https://us12.api.mailchimp.com/3.0/lists/88cc356196/members/410ae7b931f4fa24c25da4da0c0c5e80


Response: 
401 Unauthorized
{"type":"https://mailchimp.com/developer/marketing/docs/errors/","title":"API Key Invalid","status":401,"detail":"API key has been disabled","instance":"c8de5fb7-c755-45d8-9a86-c11d52f911fa"}
[2023-12-07 13:30:00] ERROR: Form 8 > Mailchimp API error: 401 Unauthorized. API Key Invalid. API key has been disabled

Request: 
GET https://us12.api.mailchimp.com/3.0/lists/88cc356196/members/fab6a15d8d456660d42c29afa55a063b


Response: 
401 Unauthorized
{"type":"https://mailchimp.com/developer/marketing/docs/errors/","title":"API Key Invalid","status":401,"detail":"API key has been disabled","instance":"be0ec18d-b0c6-b618-cff1-242e3fe748d0"}
[2023-12-07 13:30:04] ERROR: Form 8 > Mailchimp API error: 401 Unauthorized. API Key Invalid. API key has been disabled

Request: 
GET https://us12.api.mailchimp.com/3.0/lists/88cc356196/members/1e02867f2be32e3578af7fe544199da9


Response: 
401 Unauthorized
{"type":"https://mailchimp.com/developer/marketing/docs/errors/","title":"API Key Invalid","status":401,"detail":"API key has been disabled","instance":"c162071f-e899-99f9-156d-4d9e4f6839db"}
[2023-12-07 13:30:09] ERROR: Form 8 > Mailchimp API error: 401 Unauthorized. API Key Invalid. API key has been disabled

Request: 
GET https://us12.api.mailchimp.com/3.0/lists/88cc356196/members/410ae7b931f4fa24c25da4da0c0c5e80


Response: 
401 Unauthorized
{"type":"https://mailchimp.com/developer/marketing/docs/errors/","title":"API Key Invalid","status":401,"detail":"API key has been disabled","instance":"0e79fb45-e8b3-7159-d4c3-d5103ebf357e"}
[2023-12-07 13:30:13] ERROR: Form 8 > Mailchimp API error: 401 Unauthorized. API Key Invalid. API key has been disabled

Request: 
GET https://us12.api.mailchimp.com/3.0/lists/88cc356196/members/410ae7b931f4fa24c25da4da0c0c5e80


Response: 
401 Unauthorized
{"type":"https://mailchimp.com/developer/marketing/docs/errors/","title":"API Key Invalid","status":401,"detail":"API key has been disabled","instance":"066782ab-5261-6206-341b-99044254de9d"}
[2023-12-07 13:30:18] ERROR: Form 8 > Mailchimp API error: 401 Unauthorized. API Key Invalid. API key has been disabled

Request: 
GET https://us12.api.mailchimp.com/3.0/lists/88cc356196/members/410ae7b931f4fa24c25da4da0c0c5e80


Response: 
401 Unauthorized
{"type":"https://mailchimp.com/developer/marketing/docs/errors/","title":"API Key Invalid","status":401,"detail":"API key has been disabled","instance":"5790514f-c992-3500-582c-3a6d99e18596"}
[2023-12-07 14:40:15] ERROR: Form 8 > Mailchimp API error: 401 Unauthorized. API Key Invalid. API key has been disabled

Request: 
GET https://us12.api.mailchimp.com/3.0/lists/88cc356196/members/07493e21517a438c424a7c8aa59b7871


Response: 
401 Unauthorized
{"type":"https://mailchimp.com/developer/marketing/docs/errors/","title":"API Key Invalid","status":401,"detail":"API key has been disabled","instance":"10ee26c8-e60e-7107-474a-9fbfc33fcb01"}
[2023-12-07 14:40:20] ERROR: Form 8 > Mailchimp API error: 401 Unauthorized. API Key Invalid. API key has been disabled

Request: 
GET https://us12.api.mailchimp.com/3.0/lists/88cc356196/members/fab6a15d8d456660d42c29afa55a063b


Response: 
401 Unauthorized
{"type":"https://mailchimp.com/developer/marketing/docs/errors/","title":"API Key Invalid","status":401,"detail":"API key has been disabled","instance":"3ee15f91-cb84-b94a-ca5a-aa005fd12f64"}
[2023-12-07 14:40:25] ERROR: Form 8 > Mailchimp API error: 401 Unauthorized. API Key Invalid. API key has been disabled

Request: 
GET https://us12.api.mailchimp.com/3.0/lists/88cc356196/members/3a47c994102e315adc6964385c317aeb


Response: 
401 Unauthorized
{"type":"https://mailchimp.com/developer/marketing/docs/errors/","title":"API Key Invalid","status":401,"detail":"API key has been disabled","instance":"1f5ac1e5-506d-a7ed-dc5e-e2a496c99c1e"}
[2023-12-07 14:40:29] ERROR: Form 8 > Mailchimp API error: 401 Unauthorized. API Key Invalid. API key has been disabled

Request: 
GET https://us12.api.mailchimp.com/3.0/lists/88cc356196/members/07493e21517a438c424a7c8aa59b7871


Response: 
401 Unauthorized
{"type":"https://mailchimp.com/developer/marketing/docs/errors/","title":"API Key Invalid","status":401,"detail":"API key has been disabled","instance":"2e211911-5d2d-f608-cdf1-d6462e623e50"}
[2023-12-07 14:40:32] ERROR: Form 8 > Mailchimp API error: 401 Unauthorized. API Key Invalid. API key has been disabled

Request: 
GET https://us12.api.mailchimp.com/3.0/lists/88cc356196/members/07493e21517a438c424a7c8aa59b7871


Response: 
401 Unauthorized
{"type":"https://mailchimp.com/developer/marketing/docs/errors/","title":"API Key Invalid","status":401,"detail":"API key has been disabled","instance":"5f652faf-b448-2c08-77a1-2417dd64363b"}
[2023-12-07 14:40:36] ERROR: Form 8 > Mailchimp API error: 401 Unauthorized. API Key Invalid. API key has been disabled

Request: 
GET https://us12.api.mailchimp.com/3.0/lists/88cc356196/members/07493e21517a438c424a7c8aa59b7871


Response: 
401 Unauthorized
{"type":"https://mailchimp.com/developer/marketing/docs/errors/","title":"API Key Invalid","status":401,"detail":"API key has been disabled","instance":"db4e5223-fa52-df86-b018-840028951a09"}
[2023-12-07 14:41:32] ERROR: Form 8 > Mailchimp API error: 401 Unauthorized. API Key Invalid. API key has been disabled

Request: 
GET https://us12.api.mailchimp.com/3.0/lists/88cc356196/members/57a3925e2ec30567b2515eab41ba04d4


Response: 
401 Unauthorized
{"type":"https://mailchimp.com/developer/marketing/docs/errors/","title":"API Key Invalid","status":401,"detail":"API key has been disabled","instance":"c380b60f-3867-e61f-2f1f-537d2c2a8e4f"}
[2023-12-07 14:41:36] ERROR: Form 8 > Mailchimp API error: 401 Unauthorized. API Key Invalid. API key has been disabled

Request: 
GET https://us12.api.mailchimp.com/3.0/lists/88cc356196/members/3a47c994102e315adc6964385c317aeb


Response: 
401 Unauthorized
{"type":"https://mailchimp.com/developer/marketing/docs/errors/","title":"API Key Invalid","status":401,"detail":"API key has been disabled","instance":"b7c70c16-5012-7f1b-d8ce-f85b180a0811"}
[2023-12-07 14:41:40] ERROR: Form 8 > Mailchimp API error: 401 Unauthorized. API Key Invalid. API key has been disabled

Request: 
GET https://us12.api.mailchimp.com/3.0/lists/88cc356196/members/57a3925e2ec30567b2515eab41ba04d4


Response: 
401 Unauthorized
{"type":"https://mailchimp.com/developer/marketing/docs/errors/","title":"API Key Invalid","status":401,"detail":"API key has been disabled","instance":"5df3afdc-ea65-72a9-5dde-d8acf995677d"}
[2023-12-07 14:41:43] ERROR: Form 8 > Mailchimp API error: 401 Unauthorized. API Key Invalid. API key has been disabled

Request: 
GET https://us12.api.mailchimp.com/3.0/lists/88cc356196/members/fab6a15d8d456660d42c29afa55a063b


Response: 
401 Unauthorized
{"type":"https://mailchimp.com/developer/marketing/docs/errors/","title":"API Key Invalid","status":401,"detail":"API key has been disabled","instance":"e7f79828-f1e0-3184-25d7-888259070b3e"}
[2023-12-07 14:41:46] ERROR: Form 8 > Mailchimp API error: 401 Unauthorized. API Key Invalid. API key has been disabled

Request: 
GET https://us12.api.mailchimp.com/3.0/lists/88cc356196/members/fab6a15d8d456660d42c29afa55a063b


Response: 
401 Unauthorized
{"type":"https://mailchimp.com/developer/marketing/docs/errors/","title":"API Key Invalid","status":401,"detail":"API key has been disabled","instance":"fce79091-92ad-3dd6-2ae5-079cad27c99e"}
[2023-12-07 14:41:49] ERROR: Form 8 > Mailchimp API error: 401 Unauthorized. API Key Invalid. API key has been disabled

Request: 
GET https://us12.api.mailchimp.com/3.0/lists/88cc356196/members/fab6a15d8d456660d42c29afa55a063b


Response: 
401 Unauthorized
{"type":"https://mailchimp.com/developer/marketing/docs/errors/","title":"API Key Invalid","status":401,"detail":"API key has been disabled","instance":"06c606e5-3179-ba81-75ab-3bf7392b9beb"}
