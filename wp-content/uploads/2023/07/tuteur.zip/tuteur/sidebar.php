<?php
/**
 * The sidebar containing the main widget area
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package tuteur
 */

if ( ! is_active_sidebar( 'tuteur-sidebar' ) ) {
	return;
}
?>
<?php dynamic_sidebar( 'tuteur-sidebar' ); ?>
