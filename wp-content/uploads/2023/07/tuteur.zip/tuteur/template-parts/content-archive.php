<?php
/**
 * Template part for displaying posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package tuteur
 */
?>
<article id="post-<?php the_ID(); ?>" <?php post_class('tu-theme-box'); ?>>
	<header class="tuteur-entry-header">
		<?php
		if ( is_singular() ) {
			the_title( '<h4 class="tuteur-entry-title">', '</h4>' );
		}else if ( is_home() && ! is_front_page() ) {?>
			<header>
				<h1 class="tuteur-page-title tuteur-screen-reader-text"><?php single_post_title(); ?></h1>
			</header>
			<?php
		}else{
			the_title( '<h4 class="tuteur-entry-title"><a href="' . esc_url( get_permalink() ) . '" rel="bookmark">', '</a></h4>' );
		}

		if ( 'post' === get_post_type() ) {?>
			<div class="tuteur-entry-meta">
				<?php
					tuteur_posted_on();
					tuteur_posted_by();
				?>
			</div>
		<?php } ?>
	</header>

	<?php tuteur_post_thumbnail(); ?>

	<div class="tuteur-entry-content">
		<?php
		if (!empty(get_the_excerpt())) {
			the_excerpt();
		}
		
		wp_link_pages(
			array(
				'before' => '<div class="tuteur-page-links">' . esc_html__( 'Pages:', 'tuteur' ),
				'after'  => '</div>',
			)
		);
		?>
	</div>
	<footer class="tuteur-entry-footer">
		<?php tuteur_entry_footer(); ?>
	</footer>
</article>