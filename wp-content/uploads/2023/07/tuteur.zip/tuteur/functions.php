<?php
/**
 * tuteur functions and definitions
 *
 * @link https://themeforest.net/user/amentotech/portfolio
 *
 * @package tuteur
 */

if ( ! defined( 'THEME_VERSION' ) ) {
	// Replace the version number of the theme on each release.
	define( 'THEME_VERSION', '1.0.0' );
}

if ( ! function_exists( 'tuteur_setup' ) ) :
	/**
	 * Sets up theme defaults and registers support for various WordPress features.
	 *
	 * Note that this function is hooked into the after_setup_theme hook, which
	 * runs before the init hook. The init hook is too late for some features, such
	 * as indicating support for post thumbnails.
	 */
	function tuteur_setup() {
		/*
		 * Make theme available for translation.
		 * Translations can be filed in the /languages/ directory.
		 * If you're building a theme based on tuteur, use a find and replace
		 * to change 'tuteur' to the name of your theme in all the template files.
		 */
		load_theme_textdomain( 'tuteur', get_template_directory() . '/languages' );

		// Add default posts and comments RSS feed links to head.
		add_theme_support( 'automatic-feed-links' );

		/*
		 * Let WordPress manage the document title.
		 * By adding theme support, we declare that this theme does not use a
		 * hard-coded <title> tag in the document head, and expect WordPress to
		 * provide it for us.
		 */
		add_theme_support( 'title-tag' );

		/*
		 * Enable support for Post Thumbnails on posts and pages.
		 *
		 * @link https://developer.wordpress.org/themes/functionality/featured-images-post-thumbnails/
		 */
		add_theme_support( 'post-thumbnails' );

		// This theme uses wp_nav_menu() in one location.
		register_nav_menus(
			array(
				'primary-menu' 	=> esc_html__( 'Primary menu', 'tuteur' ),
				'footer-menu' 	=> esc_html__( 'Footer menu', 'tuteur' ),
			)
		);

		/*
		 * Switch default core markup for search form, comment form, and comments
		 * to output valid HTML5.
		 */
		add_theme_support(
			'html5',
			array(
				'search-form',
				'comment-form',
				'comment-list',
				'gallery',
				'caption'
			)
		);

		// Add theme support for selective refresh for widgets.
		add_theme_support( 'customize-selective-refresh-widgets' );

		/*
		* Enable support for Post Formats.  
		* See http://codex.wordpress.org/Post_Formats     
		*/
		add_theme_support('post-formats' , array (
			''
		));
		
		// Add support for responsive embedded content.
		add_theme_support( 'responsive-embeds' );

		// Add support for Block Styles.
		add_theme_support( 'wp-block-styles' );

		// Add support for full and wide align images.
		add_theme_support( 'align-wide' );

		// Add support for editor styles.
		add_theme_support( 'editor-styles' );

		// Add custom editor font sizes.
		add_theme_support(
			'editor-font-sizes',
			array(
				array(
					'name'      => esc_html__( 'Small', 'tuteur' ),
					'size'      => 15,
					'slug'      => 'small',
				),
				array(
					'name'      => esc_html__( 'Normal', 'tuteur' ),
					'size'      => 16,
					'slug'      => 'normal',
				),
				array(
					'name'      => esc_html__( 'Large', 'tuteur' ),
					'size'      => 36,
					'slug'      => 'large',
				),
				array(
					'name'      => esc_html__( 'Extra Large', 'tuteur' ),
					'size'      => 48,
					'slug'      => 'extra-large',
				),
			)
		);
		
		//theme default color 
		add_theme_support( 
			'editor-color-palette', array(
			array(
				'name' => esc_html__( 'Theme color', 'tuteur' ),
				'slug' => 'strong-theme-color',
				'color' => '#6A307D',
			),
			array(
				'name' => esc_html__( 'Theme light text color', 'tuteur' ),
				'slug' => 'light-gray',
				'color' => '#999999',
			),
			array(
				'name' => esc_html__( 'Theme very light text color', 'tuteur' ),
				'slug' => 'very-light-gray',
				'color' => '#FCFCFC',
			),
			array(
				'name' => esc_html__( 'Theme Dark text color', 'tuteur' ),
				'slug' => 'very-dark-gray',
				'color' => '#1C1C1C',
			),
		) );

		// Add support for woocommerce
		add_theme_support( 'woocommerce' );
		add_theme_support( 'wc-product-gallery-zoom' );
		add_theme_support( 'wc-product-gallery-lightbox' );
		add_theme_support( 'wc-product-gallery-slider' );
}
endif;
add_action( 'after_setup_theme', 'tuteur_setup' );

/**
 * Set the content width in pixels, based on the theme's design and stylesheet.
 *
 * Priority 0 to make it available to lower priority callbacks.
 *
 * @global int $content_width
 */
if(!function_exists('tuteur_content_width')){
	function tuteur_content_width() {
		$GLOBALS['content_width'] = apply_filters( 'tuteur_content_width', 1296 );
	}
	add_action( 'after_setup_theme', 'tuteur_content_width', 0 );
}

/**
 * Tuteur paid theme.
 *
 * @global bolean $paid
 */
if(!function_exists('tuteur_paid_theme')){
	function tuteur_paid_theme($paid = 'free') {
		return 'paid';
	}
	add_filter( 'tuteur_paid_theme', 'tuteur_paid_theme', 10);
}


/**
 * Register widget area.
 *
 * @link https://themeforest.net/user/amentotech/portfolio
 */
if(!function_exists('tuteur_widgets_init')){
	function tuteur_widgets_init() {
		register_sidebar(
			array(
				'name'          => esc_html__( 'Default sidebar', 'tuteur' ),
				'id'            => 'tuteur-sidebar',
				'description'   => esc_html__( 'Default archive side', 'tuteur' ),
				'before_widget' => '<div id="%1$s" class="widget %2$s tu-asideitem ">',
				'after_widget'  => '</div>',
				'before_title'  => '<h5>',
				'after_title'   => '</h5>',
			)
		);
		register_sidebar(
			array(
				'name'          => esc_html__( 'Single post sidebar', 'tuteur' ),
				'id'            => 'tuteur-single-sidebar',
				'description'   => esc_html__( 'Single post sidebar', 'tuteur' ),
				'before_widget' => '<div id="%1$s" class="widget %2$s tu-asideitem">',
				'after_widget'  => '</div>',
				'before_title'  => '<h5>',
				'after_title'   => '</h5>',
			)
		);
		
		register_sidebar(
			array(
				'name'          => esc_html__( 'Footer sidebar 1', 'tuteur' ),
				'id'            => 'tuteur-sidebar-f3',
				'description'   => esc_html__( 'For footer 3rd section first column', 'tuteur' ),
				'before_widget' => '<div id="%1$s" class="widget %2$s">',
				'after_widget'  => '</div>',
				'before_title'  => '<div class="tu-sidetitle"><h5>',
				'after_title'   => '</h5></div>',
			)
		);		
		register_sidebar(
			array(
				'name'          => esc_html__( 'Footer sidebar 2', 'tuteur' ),
				'id'            => 'tuteur-sidebar-f4',
				'description'   => esc_html__( 'For footer 3rd section second column', 'tuteur' ),
				'before_widget' => '<div id="%1$s" class="widget %2$s">',
				'after_widget'  => '</div>',
				'before_title'  => '<div class="tu-sidetitle"><h5>',
				'after_title'   => '</h5></div>',
			)
		);		
		register_sidebar(
			array(
				'name'          => esc_html__( 'Footer sidebar 3', 'tuteur' ),
				'id'            => 'tuteur-sidebar-f5',
				'description'   => esc_html__( 'For 3rd section 3rd column', 'tuteur' ),
				'before_widget' => '<div id="%1$s" class="widget %2$s">',
				'after_widget'  => '</div>',
				'before_title'  => '<div class="tu-sidetitle"><h5>',
				'after_title'   => '</h5></div>',
			)
		);
	}
	add_action( 'widgets_init', 'tuteur_widgets_init' );
}

/**
 * Enqueue scripts and styles.
 */
if(!function_exists('tuteur_scripts')){
	function tuteur_scripts() {
		global $tuturn_settings;
		$loading_duration	= !empty($tuturn_settings['loading_duration']) ? $tuturn_settings['loading_duration'] : 500;
		$theme_version 		= wp_get_theme('tuteur');		
		//register css
		wp_register_style( 'bootstrap', get_template_directory_uri() . '/css/bootstrap.min.css', array(), $theme_version->get('Version'));
		wp_register_style( 'feather-icons', get_template_directory_uri(). '/css/feather.css', array(),$theme_version->get('Version'), 'all' );
		wp_register_style( 'fontawesome', get_template_directory_uri(). '/css/fontawesome/fontawesome.css', array(), $theme_version->get('Version'), 'all' );
		wp_register_style( 'tuteur-style', get_stylesheet_uri(), array(), $theme_version->get('Version') );
		wp_register_style( 'tuteur-responsive', get_template_directory_uri() . '/css/responsive.css',  array(), $theme_version->get('Version'));
		//register js
		wp_register_script( 'bootstrap', get_template_directory_uri() . '/js/vendor/bootstrap.min.js', array( 'jquery' ), $theme_version->get('Version'), true );
		wp_register_script( 'tuteur-callbacks', get_template_directory_uri() . '/js/callbacks.js', array('jquery'), $theme_version->get('Version'), true );
		//css enqueue
		wp_enqueue_style('bootstrap');
		wp_enqueue_style('feather-icons');
		wp_enqueue_style('fontawesome');
		wp_enqueue_style('tuteur-style');
		wp_enqueue_style('tuteur-responsive');
		//js enqueue
		wp_enqueue_script('bootstrap');
		wp_enqueue_script('tuteur-callbacks');

		if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
			wp_enqueue_script( 'comment-reply' );
		}
		wp_localize_script('tuteur-callbacks', 'tuteur_vars', array(
			'loading_duration'			=> $loading_duration,
            'ajaxurl'					=> admin_url('admin-ajax.php'),
        ));
	}
	add_action( 'wp_enqueue_scripts', 'tuteur_scripts' );
}

/**
 * @Enque Google Font
 * @return
 */
if (!function_exists('tuteur_enqueue_google_fonts')) {
    function tuteur_enqueue_google_fonts() {
		$protocol = is_ssl() ? 'https' : 'http';		
		//Default theme font famlies
		$font_families	= array();
		$font_families[] = 'Outfit:400,500,600,700';
		$font_families[] = 'Open+Sans:400,600';
		$font_families[] = 'Gochi+Hand';		
		 $query_args = array (
			 'family' => implode('%7C' , $font_families) ,
			 'subset' => 'latin,latin-ext' ,
        );
        $theme_fonts = add_query_arg($query_args , $protocol.'://fonts.googleapis.com/css');
		wp_enqueue_style('tuteur-default-google-fonts' , esc_url_raw($theme_fonts), array () , null);
    }
    add_action('wp_enqueue_scripts' , 'tuteur_enqueue_google_fonts');
}

/**
 * Include files
 */
require get_template_directory() . '/inc/template-tags.php';
require get_template_directory() . '/inc/template-functions.php';
if ( defined( 'JETPACK__VERSION' ) ) {
	require get_template_directory() . '/inc/jetpack.php';
}

/**
 * Blog post views
 *
 * @throws error
 * @author Amentotech <theamentotech@gmail.com>
 * @return
 */
if (!function_exists('tuteur_post_views')) {
	function tuteur_post_views($args){
		if (!is_single())
			return; 
		$post_id	= !empty($args['post_id']) ? intval($args['post_id']) : '';
		$key		= !empty($args['key']) ? $args['key'] : 'tuteur_post_views';

		if (empty($post_id)) {
			global $post;
			$post_id	= $post->ID;
		}

		if (!isset($_COOKIE[$key . $post_id])) {
			setcookie($key . $post_id, $key, time() + 3600);
			$post_views	= get_post_meta($post_id, $key, true); 
			$post_views	= !empty($post_views) ? intval($post_views) : 0;
			$post_views++;
			update_post_meta($post_id, $key, $post_views);
		}
	}
	add_action('tuteur_post_views' , 'tuteur_post_views');
}
