<?php
/**
 *
 * Comments Page
 *
 * @package   Tuteur
 * @author    Amentotech
 * @link      https://themeforest.net/user/amentotech/portfolio
 * @version 1.0
 * @since 1.0
 */
global $current_user;
if (post_password_required()) {
    return;
}

if (have_comments()) { ?>
	<div id="tuteur-comments" class="tuteur-comments tu-theme-box tu-boxlg">
		<div class="tu-boxtitle"><h3><?php comments_number(esc_html__('0 comment' , 'tuteur') , esc_html__('1 comment' , 'tuteur') , esc_html__('% comments' , 'tuteur')); ?></h3></div>
		<ul class="tu-commentarea"><?php wp_list_comments(array ('callback' => 'tuteur_comments' ));?></ul>
		<?php if (get_comment_pages_count() > 1 && get_option('page_comments')) : ?>
			<div class="tuteur-haslayout tuteur-comments-paginate">
				<?php if (get_comment_pages_count() > 1 && get_option('page_comments')) : ?>
					<span class="tuteur-comment-prev"><?php previous_comments_link(esc_html__('&larr; Older comments', 'tuteur')); ?></span>
					<span class="tuteur-comment-next"><?php next_comments_link(esc_html__('Newer comments &rarr;', 'tuteur')); ?></span>
				<?php endif; ?>
			</div>
		<?php endif;?>
	</div>	
<?php } ?>

<?php if ( ! comments_open() && get_comments_number() && post_type_supports( get_post_type(), 'comments' ) ) {?>
		<div class="tuteur-comments-closed"><?php esc_html_e('Comments are closed.', 'tuteur');?></div>
<?php }?>

<?php if ( comments_open() ) {
	$userType	= apply_filters('tuturnGetUserType', $current_user->ID );

	if($userType == 'instructor' || $userType == 'student'){
		$profile_url	= tuturn_get_page_uri('dashboard');
	} else {
		$profile_url	= admin_url( "profile.php" );
	}
	$comments_args = array(
		'must_log_in'			=> '<div class="form-group"><p class="tuteur-must-log-in">' .  sprintf( __( "You must be %slogged in%s to post a comment.", 'tuteur' ), '<a href="'.esc_url(wp_login_url( apply_filters( 'the_permalink', get_permalink( ) ) )).'">', '</a>' ) . '</p></div>',
		'logged_in_as'			=> '<div class="form-group"><p class="tuteur-logged-in-as">' . esc_html__( "Logged in as",'tuteur' ).' <a href="' .esc_url( $profile_url ).'">'.$user_identity.'</a>. <a href="' .esc_url(wp_logout_url(get_permalink())).'" title="' . esc_attr__("Log out of this account", 'tuteur').'">'. esc_html__("Log out &raquo;", 'tuteur').'</a></p></div>',
		'fields' 				=> apply_filters( 'tuteur_default_comment_fields', array(
			'author'	=> '<div class="form-group  form-group-half"><label class="tu-label">'. esc_html__('Full Name', 'tuteur').'</label><div class="tu-placeholderholder"><input type="text" name="author" id="author" value="'. esc_attr( $commenter['comment_author'] ) .'" placeholder="'. esc_attr__("Your name (required)", 'tuteur').'" size="22" tabindex="1" aria-required="true" class="form-control" /></div></div>',
			'email'		=> '<div class="form-group  form-group-half"><label class="tu-label">'. esc_html__('Email address', 'tuteur').'</label><div class="tu-placeholderholder"><input type="text" name="email" id="email" value="'. esc_attr( $commenter['comment_author_email'] ) .'" placeholder="'. esc_attr__("Your email (required)", 'tuteur').'" size="22" tabindex="2" aria-required="true" class="form-control"  /></div></div>',
			'url'		=> '<div class="form-group"><label class="tu-label">'. esc_html__('Website', 'tuteur').'</label><div class="tu-placeholderholder"><input type="text" name="url" id="url" value="'. esc_attr( $commenter['comment_author_url'] ) .'" placeholder="'. esc_attr__("Website", 'tuteur').'" size="22" tabindex="3" class="form-control" /></div></div>'
		)),
		'comment_field'			=> '<div class="form-group"><label class="tu-label">'. esc_html__('Description', 'tuteur').'</label><div class="tu-placeholderholder"><textarea name="comment" id="comment" cols="39" rows="5" tabindex="4" class="form-control" placeholder="'. esc_attr__("Type your comment", 'tuteur').'"></textarea></div></div>',
		'notes'                	=> '' ,
		'comment_notes_before' 	=> '' ,
		'comment_notes_after'  	=> '' ,
		'id_form'              	=> 'tu-themeform' ,
		'id_submit'            	=> 'tuteur-formtheme' ,
		'class_form'           	=> 'tu-themeform' ,
		'class_submit'         	=> 'tu-theme-btn',
		'class_container'      	=> 'comment-respond tu-theme-box',
		'name_submit'          	=> 'submit' ,
		'title_reply'          	=> esc_html__('Leave your comment' , 'tuteur') ,
		'title_reply_to'       	=> esc_html__('Leave a reply to %s' , 'tuteur') ,
		'title_reply_before'   	=> '<div class="tu-boxtitle"><h3>' ,
		'title_reply_after'    	=> '</h3></div>' ,
		'cancel_reply_before'  	=> '' ,
		'cancel_reply_after'   	=> '' ,
		'cancel_reply_link'    	=> esc_html__('Cancel reply' , 'tuteur') ,
		'label_submit'        	=> esc_html__('Post comment' , 'tuteur') ,
		'submit_button'        	=> '<div class="form-group"><button name="%1$s" type="submit" id="%2$s" class="tu-theme-btn" value="%4$s"> '.esc_html__( 'Post comment', 'tuteur' ).'</button></div>' ,
		'submit_field'         	=> ' %1$s %2$s ' ,
		'format'               	=> 'xhtml' ,
	);
	comment_form($comments_args);	
}
