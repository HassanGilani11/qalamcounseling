<?php
/**
 * Tuteur footer template
 *
 * @link https://themeforest.net/user/amentotech/portfolio
 *
 * @package tuteur
 */
global $tuturn_settings;

$footer_copyright 	= !empty($tuturn_settings['copyright']) ? $tuturn_settings['copyright'] : esc_html__('Copyright &copy;', 'tuteur') . date('Y') . '&nbsp;' . get_bloginfo();
$footer_menu 		= !empty($tuturn_settings['footer_menu']) ? $tuturn_settings['footer_menu'] : '';
$topbar	= 'tu-empty-sidebar';

if ( is_active_sidebar('tuteur-sidebar-f3')
	|| is_active_sidebar('tuteur-sidebar-f4')
	|| is_active_sidebar('tuteur-sidebar-f5')
) {
	$topbar	= '';
}
?>
<footer>
	<div class="tu-footerdark <?php echo esc_attr($topbar);?>">
		<?php if ( empty($topbar) ) {?>
			<div class="tu-footerwrap">
				<div class="container">
					<div class="row">
						<?php if ( is_active_sidebar('tuteur-sidebar-f3')  
						|| is_active_sidebar('tuteur-sidebar-f4') 
						|| is_active_sidebar('tuteur-sidebar-f5')) {?>
							<div class="col-12 tu-seperator">
								<div class="row gy-4">
									<?php if ( is_active_sidebar('tuteur-sidebar-f3') ){?>
										<div class="col-md-6 col-lg-4 tuteur-sidebar-f3"><?php dynamic_sidebar('tuteur-sidebar-f3'); ?></div>
									<?php }?>
									<?php if ( is_active_sidebar('tuteur-sidebar-f4') ){?>
										<div class="col-md-6 col-lg-4 tuteur-sidebar-f4"><?php dynamic_sidebar('tuteur-sidebar-f4'); ?></div>
									<?php }?>
									<?php if ( is_active_sidebar('tuteur-sidebar-f5') ){?>
										<div class="col-md-12 col-lg-4 tuteur-sidebar-f5"><?php dynamic_sidebar('tuteur-sidebar-f5'); ?></div>
									<?php }?>
								</div>
							</div>
						<?php }?>
					</div>
				</div>
			</div>
		<?php }?>
		<div class="tu-footercopyright">
			<div class="container">
				<div class="tu-footercopyright_content">
					<?php if(!empty($footer_copyright)){?>
						<p><?php echo esc_html($footer_copyright);?></p>
					<?php }?>
					<?php if(!empty($footer_menu)){?>
						<?php
							wp_nav_menu(
								array(
									'menu_class'		=> 'tu-footercopyright_list',
									'theme_location' 	=> 'footer-menu',
									'menu_id'        	=> 'footer-menu',
								)
							);
						?>
					<?php }?>
				</div>
			</div>
		</div>
	</div>
</footer>
