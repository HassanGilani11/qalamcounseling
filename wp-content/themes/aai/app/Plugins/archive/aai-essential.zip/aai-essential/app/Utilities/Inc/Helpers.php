<?php

/**
 * @package  aai-essential
 */

namespace AaiEssential\Utilities;

class Helpers
{
}
