<?php

/**
 * @package  aai-essential
 */

namespace AaiEssential\Base;

use AaiEssential\Base\BaseController;

/**
 * 
 */
class Enqueue extends BaseController
{
	public function register()
	{
	}
}
